python predict.py --category_names cat_to_name.json --top_K 5 --gpu False image_07895.jpg checkpoint.pth
