python train.py --arch vgg13  --epochs 5 flowers --gpu True
